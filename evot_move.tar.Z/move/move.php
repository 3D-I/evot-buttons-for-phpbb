<?php

/*
*
* moves the whole topic to another place like unwanted topics forum
*
* @copyright (c) 2019 Z.Lisiecki (zlisiecki)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* @package evot/move
*
*/

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : '../../../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
include($phpbb_root_path . 'includes/functions_mcp.' . $phpEx);
//require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
include_once($phpbb_root_path . 'ext/evot/move/movelib.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup();
$user->add_lang_ext('evot/move', 'move');
$mode_ni = $user->lang['EMOVE_NI'];
$mode_na = $user->lang['EMOVE_NA'];
$mode_sp = $user->lang['EMOVE_SP'];

$mode = request_var ('mode', '');
if (!isset ($mode) || !$mode || $mode === '') {
	trigger_error ('move.php: ' . $user->lang['EMOVE_MODE_NOTSET']);
}
if ($mode != $mode_ni && $mode != $mode_na && $mode != $mode_sp) {
	$msg  = 'move.php: ';
	$msg .= $user->lang['EMOVE_WRONG_MODE'] . ' ' .  $mode;
	trigger_error ($msg);
}

/*
* this is the forum where the thread to move is comming from
*/

$forum_id = request_var ('f', '');
if (!isset ($forum_id)) {
	trigger_error ('move.php: ' . $user->lang['EMOVE_FORUM_NOTSET']);
}

$topic_id = request_var ('t', '');
if (!isset ($topic_id)) {
	trigger_error ('move.php: ' . $user->lang['EMOVE_TOPIC_NOTSET']);
}

// Only registered users and not bots can go beyond this point
if (!$user->data['is_registered']) {
	if ($user->data['is_bot']) {
		redirect(append_sid("{$phpbb_root_path}index.$phpEx"));
	}
	login_box('', $user->lang['LOGIN_EXPLAIN_MCP']);
}

// check for the users moderators power (globally or locally)
if (!$auth->acl_getf_global('m_')) { trigger_error('NOT_AUTHORISED'); }

if ($mode === 'niechciane')	 {
	$title = $user->lang['EMOVE_NIT_TITLE'];
	//$forum_desc = $user->lang['EMOVE_NIT_TITLE'];
	$forum_desc = '';
	$forum_image = 'images/forumicons/trashcan.png';
	$lock_it = false;
} elseif ($mode === 'nieaktualne') {
	$title = $user->lang['EMOVE_NAT_TITLE'];
	//$forum_desc = $user->lang['EMOVE_NAT_TITLE'];
	$forum_desc = '';
	$forum_image = 'images/forumicons/ark.png';
	$lock_it = true;
} elseif ($mode === 'spam') {
	$title = $user->lang['EMOVE_SPT_TITLE'];
	//$forum_desc = $user->lang['EMOVE_SPT_TITLE'];
	$forum_image = 'ext/evot/move/images/spam04.png';
	$lock_it = true;
} else {
	$msg = $user->lang['EMOVE_WRONG_MODE'] . ' ' .  $mode;
	trigger_error ($msg);
}

/* check if we are already inside this forum */
$current_name = forum_name ($forum_id);
$parent_forum = parent_forum ($forum_id);
if ($current_name === $user->lang['EMOVE_NIT_TITLE'] ||
	$current_name === $user->lang['EMOVE_NAT_TITLE'] ||
	$current_name === $user->lang['EMOVE_SPT_TITLE']) {
	if ($current_name == $title) {
		/*
		* We are inside, just move this tread out of it to it's original place
		*/
		$destination_forum_id = $parent_forum;
	} else {
		/*
		* We are already inside another special forum
		* e.g. moving from niechciane to spam
		*/
		$destination_forum_id = (int) find_forum_by_name ($parent_forum, $title);
		if (!$destination_forum_id || $destination_forum_id === 0) {
			$destination_forum_id =
			create_forum ($parent_forum, $title, $forum_desc, $forum_image, $lock_it);
		}
	}
} else {
	$destination_forum_id = (int) find_forum_by_name ($forum_id, $title);
	if (!$destination_forum_id || $destination_forum_id === 0) {
		/*
		* if this forum does not exist, create it
		*/
		$destination_forum_id =
		create_forum ($forum_id, $title, $forum_desc, $forum_image, $lock_it);
	}
}

/* this is the nick name of the moderator performing this task */
$who_moves	= $user->data['username'];
$post_id = first_post_in_topic ($topic_id);
$author_id = topic_author ($topic_id, $post_id);
$adr = "{$phpbb_root_path}viewtopic.php?f=$forum_id";
$link = '<a href="' . $adr . '">' . $adr . '</a>';

/*
* an actual move is here
*
*	move_to_another_forum ($topic_id, $destination_forum_id);
*/

/*
* notify the author, log it and return 
*/
$fpath = "{$phpbb_root_path}viewforum.$phpEx";
$tpath = "{$phpbb_root_path}viewtopic.$phpEx";
$ppath = "{$phpbb_root_path}viewtopic.$phpEx&f=$forum_id&t=$topic_id";
$src_url  = append_sid($fpath, "f=$forum_id");
$dst_url  = append_sid($tpath, "f=$destination_forum_id&amp;t=$topic_id");
$src_link = "<a href=\"$user->host/$src_url\">$forum_id</a>";
$dst_link = "<a href=\"$user->host/$dst_url\">$topic_id</a>";

if ($mode === $user->lang['EMOVE_NI']) {
	$msg = sprintf ($user->lang['EMOVE_LOG_NIT_MOVED'], $dst_link);
	add_log('mod', $forum_id, $topic_id, $msg, 'by ', $who_moves);
	$msg = sprintf ($user->lang['EMOVE_PM_TOPIC_MOVED'],
		$ppath, "$fpath&f=$forum_id",
		$who_moves,
		"$fpath&f=$destination_forum",
		$user->lang['EMOVE_NIT_TITLE']);
	notify_user ($author_id, $msg);
} elseif ($mode === $user->lang['EMOVE_NA']) {
	$msg = sprintf ($user->lang['EMOVE_LOG_NAT_MOVED'], $dst_link);
	add_log('mod', $forum_id, $topic_id, $msg, 'by ', $who_moves);
	$msg = sprintf ($user->lang['EMOVE_PM_TOPIC_MOVED'],
		$ppath,
		"$fpath&f=$forum_id",
		$who_moves,
		"$fpath&f=$destination_forum",
		$user->lang['EMOVE_NAT_TITLE']);
	notify_user ($author_id, $msg);
} elseif ($mode === 'spam') {
	// do not log, but update statistics here
	;
}

/*
* go back to the previous forum
*/
$url = append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id);
redirect($url);

//never reached
make_jumpbox(append_sid("{$phpbb_root_path}viewforum.$phpEx","f=$forum_id"));


/*
* move a topic to another forum
*/
function move_to_another_forum ($topic_id, $forum_id)
{
	global $user, $db, $auth, $config, $phpbb_root_path, $phpEx;

	$sql = 'SELECT forum_id from ' . TOPICS_TABLE . '
		WHERE topic_id = ' . $topic_id;
	if (!$db->sql_query($sql)) {
		$msg  = 'move.php -> move_to_another_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
		trigger_error($msg);
	}
	if (!$db->sql_query($sql)) {
		$msg  = 'move.php -> move_to_another_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
		trigger_error($msg);
	}
	$old_forum_id = (int) $db->sql_fetchfield('forum_name');

	$sql = 'UPDATE ' . TOPICS_TABLE . '
		SET forum_id = ' . $forum_id . '
		WHERE topic_id = ' . $topic_id;
	if (!$db->sql_query($sql)) {
		$msg  = 'move.php -> move_to_another_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
		trigger_error($msg);
	}
	// Sync fora
	$forum_ids = array (
		$old_forum_id,
		$forum_id,
	);
	include_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
	//sync('topic_reported', 'topic_id', $topic_id);
	//sync('topic_attachment', 'topic_id', $topic_ids;
	sync('forum', 'forum_id', $forum_ids, true, true);
	//update_posted_info($topic_ids);
}

?>
