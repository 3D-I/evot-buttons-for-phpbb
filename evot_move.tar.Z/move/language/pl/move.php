<?php
/**
*
* evot moves [Polski]
*
* @package evot
* @version $Id$
* @copyright (c) 2019 zbyszek.evot.org
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(


// mody

	'EMOVE_NI'				=>	'niechciane',
	'EMOVE_NA'				=>	'nieaktualne',
	'EMOVE_SP'				=>	'spam',


// nazwy przycisków

	'EMOVE_NI_TITLE'		=>	'Niechciane',
	'EMOVE_NA_TITLE'		=>	'Nieaktualne',
	'EMOVE_SP_TITLE'		=>	'Spam',


// nazwy wątków

	'EMOVE_NIP_TITLE'		=>	'Niechciane posty',
	'EMOVE_NAP_TITLE'		=>	'Nieaktualne posty',
	'EMOVE_NIT_TITLE'		=>	'Niechciane tematy',
	'EMOVE_NAT_TITLE'		=>	'Nieaktualne tematy',
	'EMOVE_SPT_TITLE'		=>	'SPAM',
	'EMOVE_SPS_TITLE'		=>	'Dział techniczny',


// opisy działań

	'EMOVE_TMOVE_TITLE'		=>	'Przesuń wątek do niechcianych',
	'EMOVE_AMOVE_TITLE'		=>	'Przesuń wątek do nieaktualnych',
	'EMOVE_SPAM_TITLE'		=>	'Przesuń wątek do spamu',

	'EMOVE_NI_TITLE_B'		=>	'Przywróć z niechcianych',
	'EMOVE_NA_TITLE_B'		=>	'Przywróć z nieaktualnych',
	'EMOVE_SP_TITLE_B'		=>	'Przywróć ze spamu',


// znaczenie działań przycisków nad postem

	'EMOVE_PMOVE1_EXPLAIN'	=>	'Przesuń post do niechcianych',
	'EMOVE_PMOVE2_EXPLAIN'	=>	'Przesuń post do niechcianych,

poinformuj autora przez PM
i wróć do postu, aby go edytować',
	'EMOVE_PSPAM_EXPLAIN'	=>	'Przesuń post do spamu.

To oznacza w odróżnieniu od skasowania postu,
że jego zachowany numer IP posłuży potem do identyfikacji spamowiczów,
którzy mogą utracić dostęp do forum.',


// znaczenia działań ponad wątkiem oraz w narzędziach

	'EMOVE_TMOVE_EXPLAIN'	=>	'Przesuń cały wątek do niechcianych wątków
i poinformuj autora przez PM',
	'EMOVE_AMOVE_EXPLAIN'	=>	'Przesuń cały wątek do nieaktualnych wątków',
	'EMOVE_TSPAM_EXPLAIN'	=>	'Przesuń cały wątek do spamu.

To oznacza w odróżnieniu od skasowania tego wątku,
że IP pierwszego postu zostanie zachowany
i posłużą potem do identyfikacji spamowiczów,
którzy mogą utracić przez to dostęp do forum.',


	'EMOVE_PMOVEB_EXPLAIN'	=>	'Przesuń post z powrotem do oryginalnego wątku',
	'EMOVE_TMOVEB_EXPLAIN'	=>	'Przesuń wątek z powrotem do oryginalnego działu',


// wpisy do postów

	'EMOVE_UWAGA_MODER'		=>	'------------- uwaga moderatora ',
	'EMOVE_POST_MOVED'		=>	'Post został przesunięty z tematu: ',
	'EMOVE_TOPIC_MOVED'		=>	'Temat został przesunięty z działu: ',
	'EMOVE_TOPIC_TITLE'		=>	'Temat został przesunięty do działu niechcianych tematów',
	'EMOVE_NI_TEXT'			=>	'Niechciane posty z tego działu znaleźć można w tym temacie.',
	'EMOVE_POST_TITLE'		=>	'Post przesunięty do niechcianych postów',


// komunikaty wysłane do użytkownika przez PM

	'EMOVE_PM_TOPIC_MOVED'	=>  'Twój temat %1$s został z działu %2$s przesunięty przez moderatora %3$s do działu %4$s.',
	'EMOVE_PM_POST_MOVED'	=>	'Twój post %1$s został przesunięty przez moderatora %2$s do %3$s.',


// komunikaty logowań

	'EMOVE_LOG_NIP_MOVED'	=>	'<strong>Post „%1$s” został przeniesiony do niechcianych postów</strong>',
	'EMOVE_LOG_NAP_MOVED'	=>	'<strong>Post „%1$s” został przeniesiony do nieaktualonych postów</strong>',
	'EMOVE_LOG_SPP_MOVED'	=>	'<strong>Post „%1$s” został przeniesiony do spamu</strong>',
	'EMOVE_LOG_PMOVED_BACK'	=>	'<strong>Post „%1$s” został przeniesiony z powrotem z %2$s do oryginalnego wątku</strong>',
	'EMOVE_LOG_NIT_MOVED'	=>	'<strong>Temat „%1$s” został przeniesiony do niechcianych tematów</strong>',
	'EMOVE_LOG_NAT_MOVED'	=>	'<strong>Temat „%1$s” został przeniesiony do nieaktualnych tematów</strong>',
	'EMOVE_LOG_SPT_MOVED'	=>	'<strong>Temat „%1$s” został przeniesiony do spamu</strong>',
	'EMOVE_LOG_TMOVED_BACK'	=>	'<strong>Temat „%1$s” został przeniesiony z „%2$s” z powrotem do oryginalnego działu</strong>',

	'EMOVE_LOG_TOPIC_ADD'	=>	'<strong>Nowy wątek „%1$s” został utworzony w „%2$s”</strong>',
	'EMOVE_LOG_FORUM_ADD'	=>	'<strong>Nowy dział „%1$s” został utworzony w „%2$s”</strong>',

// komunikaty błędów

	'EMOVE_CANNOTQUERY'		=>	'Couldn\'t query',
	'EMOVE_CANNOTFETCH'		=>	'Couldn\'t fetch',
	'EMOVE_TOPIC_NOTSET'	=>	'Błąd programu: brak topic_id',
	'EMOVE_POST_NOTSET'		=>	'Błąd programu: brak post_id',
	'EMOVE_FORUM_NOTSET'	=>	'Błąd programu: brak forum_id',
	'EMOVE_MODE_NOTSET'		=>	'Błąd programu: nie podany mode',
	'EMOVE_WRONG_MODE'		=>	'Błąd programu: nieprawidłowy mode: ',
	'EMOVE_CANNOT_BACK'		=>	'Powrót tematu na pierwotne miejsce
nie jest jeszcze gotowy.
Przywróć go odręcznie',
	'EMOVE_NO_TECH'			=>	'Brak działu technicznego.
Utwórz go odręcznie.',
	'EMOVE_T_NO_AUTHOR'		=>	'Błąd bazy danych, nie można znaleźć autora tematu: ',
	'EMOVE_P_NO_AUTHOR'		=>	'Błąd bazy danych, nie można znaleźć autora postu: ',
	'EMOVE_NO_AUTHOR'		=>	'Błąd bazy danych, nie można znaleźć autora.
Prawdopodobnie autor tematu jest inny niż autor pierwszego postu w tym temacie.',
	'EMOVE_NOPREVIOUS'		=>	'Poprzedni post nie istnieje.

Zamiast przesunąć pierwszy lub jedyny post tego wątku
użyj innego przycisku aby przesunąć cały wątek.',
	'EMOVE_CANNOT_UPDATE'	=>	'Błąd programu lub bazy danych: cannot update forum data.',
	'EMOVE_CFP_FAILED'		=>	'Błąd programu lub bazy danych: copy_forum_permissions() failed.',
	'EMOVE_NO_INFO'			=>	'Post nie podaje informacji skąd został przesunięty.',
	'EMOVE_WRONG_INFO'		=>	'Post podaje fałszywą informację skąd został przesunięty.',
	'EMOVE_SAME_TOP'		=>	'Próba przesunięcia do tego samego wątku.',
	'EMOVE_ANOTHER_FOR'		=>	'Post pochodzi z innego działu forum.',
	'EMOVE_TOPIC_ID0'		=>	'W bazie danych topic_id = 0 dla post_id = ',
	'EMOVE_NOUNWANTED_FORUM'	=>	'Brak działu niechcianych wątków,
otwórz go odręcznie',
	'EMOVE_NOSTALE_FORUM'	=>	'Brak działu nieaktualnych tematów,
otwórz go odręcznie',


// inne komunikaty na ekran

	'EMOVE_MODER_NOTE'		=>	'Notatka moderatora dołączona.',
	'EMOVE_POST_RETURNED'	=>	'Post został przywrócony do oryginalnego wątku',
	'EMOVE_CANNOTMOVEFIRST'	=>	'To jest pierwszy post w wątku !

Rozważ przesuniecie całego wątku,
albo użyj guzika na prawo obok, który informuje także autora.
Teraz wróć guzikiem cofnięcia przeglądarki. ',


// tagi czynności

	'EMOVE_RETURN_POST'		=>	'Wróć do przywróconego postu',
	'EMOVE_RETURN_NIECH'	=>	'Pozostań w wątku niechcianych postów',
	'EMOVE_RETURN_FORUM'	=>	'Wróć do oryginalnego działu forum',

    ));
?>
