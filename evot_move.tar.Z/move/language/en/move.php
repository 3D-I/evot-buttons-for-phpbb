<?php
/**
*
* evot moves [Polish]
*
* @package evot
* @version $Id$
* @copyright (c) 2019 zbyszek.evot.org
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(


// mods

	'EMOVE_NI'				=>	'unwanted',
	'EMOVE_NA'				=>	'outofdate',
	'EMOVE_SP'				=>	'spam',


// button names

	'EMOVE_NI_TITLE'		=>	'Unwanted',
	'EMOVE_NA_TITLE'		=>	'Outofdate',
	'EMOVE_SP_TITLE'		=>	'Spam',


// topic names

	'EMOVE_NIP_TITLE'		=>	'Unwanted posts',
	'EMOVE_NAP_TITLE'		=>	'Out-of-date posts',
	'EMOVE_NIT_TITLE'		=>	'Unwanted topics',
	'EMOVE_NAT_TITLE'		=>	'Out-of-date topics',
	'EMOVE_SPT_TITLE'		=>	'SPAM',
	'EMOVE_SPS_TITLE'		=>	'technical forum',


// descriptions of actions

	'EMOVE_TMOVE_TITLE'		=>	'Move the topic to unwanted topics',
	'EMOVE_AMOVE_TITLE'		=>	'Move the topic to out-of-date topics',
	'EMOVE_SPAM_TITLE'		=>	'Move the topic to spam',

	'EMOVE_NI_TITLE_B'		=>	'Restore from unwanted',
	'EMOVE_NA_TITLE_B'		=>	'Restore from out-of-date',
	'EMOVE_SP_TITLE_B'		=>	'Restore from spamu',


// the meaning of button actions

	'EMOVE_PMOVE1_EXPLAIN'	=>	'Move a post to unwanted posts',
	'EMOVE_PMOVE2_EXPLAIN'	=>	'Move a post to unwanted posts,

inform the author by PM
and jump to this post to edit it',
	'EMOVE_PSPAM_EXPLAIN'	=>	'Move a post to spam.

This means in the opposite to deleting such post,
that it\'s stored IP will help to identify a spammer
and he can lose forum access in the future.',


// the meaning of actions above a topic and in tools

	'EMOVE_TMOVE_EXPLAIN'	=>	'Move the whole topic to unwanted topics,
inform the authora with PM',
	'EMOVE_AMOVE_EXPLAIN'	=>	'Move the whole topic to out-of-date tropics',
	'EMOVE_TSPAM_EXPLAIN'	=>	'Move the whole topic to spam.

This means in the opposite to deleting such topic,
that the IP of the first post will be stored
and it helps to indentify spammers,
which may lose their accounts';

	'EMOVE_PMOVEB_EXPLAIN'	=>	'Move the post back to the original topic',
	'EMOVE_TMOVEB_EXPLAIN'	=>	'Move the topic back to the original place',


// appended to the posts

	'EMOVE_UWAGA_MODER'		=>	'------------- moderators note ',
	'EMOVE_POST_MOVED'		=>	'This post has been moved from the topic: ',
	'EMOVE_TOPIC_MOVED'		=>	'The topic has been moves from forum: ',
	'EMOVE_TOPIC_TITLE'		=>	'The topic has been moved to the forum of unwanted posts.',
	'EMOVE_POST_TITLE'		=>	'The post has been moved to unwanted posts',


// notices send to the user by PM

	'EMOVE_PM_TOPIC_MOVED'	=>  'Your topic „%1$s” has been moved by the moderator „%2$s” to %3$s in  %4$s forum.',
	'EMOVE_PM_POST_MOVED'	=>	'Your post „%1$s” has been by the moderator %„%1$s” to „%1$s” in %3$s.',


// loging

	'EMOVE_LOG_NIP_MOVED'	=>	'<strong>Post „%1$s” has been moved przeniesiony do niechcianych postów</strong>',
	'EMOVE_LOG_NAP_MOVED'	=>	'<strong>Post „%1$s” has been moved to posts out-of-topic</strong>',
	'EMOVE_LOG_SPP_MOVED'	=>	'<strong>Post „%1$s” has been moved to spam</strong>',
	'EMOVE_LOG_PMOVED_BACK'	=>	'<strong>Post „%1$s” has been moved back from „%2$s” to the original topic</strong>',
	'EMOVE_LOG_NIT_MOVED'	=>	'<strong>Topic „%1$s” has been moved to unwanted topics</strong>',
	'EMOVE_LOG_NAT_MOVED'	=>	'<strong>Topic „%1$s” has been moved to out-of-date topics </strong>',
	'EMOVE_LOG_SPT_MOVED'	=>	'<strong>Topic „%1$s” has been moved to spam</strong>',
	'EMOVE_LOG_TMOVED_BACK'	=>	'<strong>Topic „%1$s” has been moved back to the original forum </strong>',

	'EMOVE_LOG_TOPIC_ADD'	=>	'<strong>New topic „%1$s” has been created in „%2$s”.</strong>',</strong>',
	'EMOVE_LOG_FORUM_ADD'	=>	'<strong>New forum „%1$s” has been created in „%2$s”.</strong>',

// error codes

	'EMOVE_CANNOTQUERY'		=>	'Couldn\'t query',
	'EMOVE_CANNOTFETCH'		=>	'Couldn\'t fetch',
	'EMOVE_TOPIC_NOTSET'	=>	'Program error : lack of topic_id',
	'EMOVE_POST_NOTSET'		=>	'Program error : lack of post_id',
	'EMOVE_FORUM_NOTSET'	=>	'Program error : lack of forum_id',
	'EMOVE_MODE_NOTSET'		=>	'Program error : no mode specified',
	'EMOVE_WRONG_MODE'		=>	'Program error : wrong mode: ',
	'EMOVE_CANNOT_BACK'		=>	'Returning of a topics to is's original place

not yet ready.
Return it by hand',
	'EMOVE_NO_TECH'			=>	'Lack of technical forum.
Create it by hand.',
	'EMOVE_T_NO_AUTHOR'		=>	'Database error, cannot identify the topics author: ',
	'EMOVE_P_NO_AUTHOR'		=>	'Database error, cannot identify the post author: ',
	'EMOVE_NO_AUTHOR'		=>	'Database error, cannot find the author.
Probably the topic and a first post author differ from each other';
	'EMOVE_NOPREVIOUS'		=>	'Previous post does not exist.

Instaed of moveing the first post of this topic
consider moving the whole topic.';

	'EMOVE_CANNOT_UPDATE'	=>	'Program or database error: cannot update forum data.',
	'EMOVE_CFP_FAILED'		=>	'Program or database error: copy_forum_permissions() failed.',
	'EMOVE_NO_INFO'			=>	'No information where this post has been moved.',
	'EMOVE_WRONG_INFO'		=>	'False information where this post has been moved from.',
	'EMOVE_SAME_TOP'		=>	'The trial to move to the same topic.',
	'EMOVE_ANOTHER_FOR'		=>	'Post is comming from another forum.',
	'EMOVE_TOPIC_ID0'		=>	'In the database topic_id = 0 for post_id = ',
	'EMOVE_NOUNWANTED_FORUM'	=>	'No forum for unwanted topics,
create it by hand',
	'EMOVE_NOSTALE_FORUM'	=>	'Lack of forum for topics out-of-date,
create it by hand',


// other messages put on the screen

	'EMOVE_MODER_NOTE'		=>	'Moderators\' note attached.',
	'EMOVE_POST_RETURNED'	=>	'The post has been moved back to it\'s original topis.',
	'EMOVE_CANNOTMOVEFIRST'	=>	'This is the first post in a topic !

Consider moving the whole topic,
or use a button on the right, which informs also the author.
Return with the browser button now. ',


// tagi czynności

	'EMOVE_RETURN_POST'		=>	'Jump to the reurutned post',
	'EMOVE_RETURN_NIECH'	=>	'Stay in a topic of unwanted posts',
	'EMOVE_RETURN_FORUM'	=>	'Return to the original forum',

    ));
?>
