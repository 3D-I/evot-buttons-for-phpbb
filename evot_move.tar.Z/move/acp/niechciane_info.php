<?php
/**
*
* @package phpBB Extension - move to niechciane
* @copyright (c) 2019 evot.org
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace evot\move\acp;

class niechciane_info
{
	public function module()
	{
		return array(
			'filename'  => '\evot\move\acp\niechciane_module',
			'title'     => 'ACP_MOVE_TO_NIECHCIANE',
			'modes'     => array(
				'settings' => array(
					'title' => 'ACP_NIECHCIANE_CONFIG',
					'auth' => 'ext_evot/move && acl_a_board',
					'cat' => array('ACP_CAT_DOT_MODS')
				),
			),
		);
	}
}
