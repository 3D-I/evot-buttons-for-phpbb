<?php
/**
*
* @package phpBB evot move
* @copyright (c) 2019 Z.Lisiecki
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace evot\move\acp;

class niechciane_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	function main($id, $mode)
	{
		global $db, $user, $auth, $template, $cache, $request;
		global $config, $phpbb_root_path, $phpbb_admin_path, $phpEx;

		$this->tpl_name = 'acp_niechciane_config';
		$this->page_title = $user->lang['NIECHCIANE_CONFIG'];
		add_form_key('acp_niechciane_config');
      
		$submit = $request->is_set_post('submit');
		if ($submit) {
			if (!check_form_key('acp_niechciane_config')) {
				trigger_error('FORM_INVALID');
			}
			$config->set('move_enable',	$request->variable('move_enable', 0));
			$config->set('move_search',	$request->variable('move_search', 0));
			$config->set('move_image_url',	$request->variable('move_image_url', ''));
			$config->set('move_image_link', $request->variable('move_image_link', ''));
			$config->set('move_target',	$request->variable('move_target', 0));
			trigger_error($user->lang['MOVE_CONFIG_SAVED'] . adm_back_link($this->u_action));
		}
		$template->assign_vars(array(
			'MOVE_VERSION'		=> (isset($config['move_version']))
										 ? $config['move_version'] : '',
			'MOVE_ENABLE'		=> (!empty($config['move_enable'])) ? true : false,
			'MOVE_SEARCH'		=> (!empty($config['move_search'])) ? true : false,
			'MOVE_IMAGE_URL'	=> (isset($config['move_image_url'])) ?
										 $config['rightheaderimage_image_url'] : '',
			'MOVE_IMAGE_LINK'	=> (isset($config['move_image_link'])) ?
										 $config['rightheaderimage_image_link'] : '',
			'MOVE_TARGET'		=> (!empty($config['move_target'])) ? true : false,
			'U_ACTION'			=> $this->u_action,
			)
		);
	}
}
