# phpBB "move to unwanted" button

## Install

1.	Download the latest release.
2.	Unzip the downloaded release in ext/evot changing the name of the folder to `move`.
	If done correctly, you'll have the main extension class at (your forum root)/ext/evot/move/composer.json.
3. Navigate in the ACP to `Customise -> Manage extensions` and enable this ext.

## Uninstall

1. Disable te ext in ACP->`Customise -> Extension Management -> Extensions`.
2. To permanently uninstall, click `Delete Data` and delete the `/ext/evot/move` folder.

## License
[GNU General Public License v2](http://opensource.org/licenses/GPL-2.0)
