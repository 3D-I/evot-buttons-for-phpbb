<?php
/**
*
* @package phpBB Extension - evot, niechciane
* @copyright (c) 2017 evot.org
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace evot\move\migrations;

class update_1_0_1 extends \phpbb\db\migration\migration
{
   static public function depends_on()
   {
      return array('\evot\move\migrations\niechciane_schema');
   }

   public function update_data()
   {
      return array(
         // Add configs
         array('config.update', array('niechciane_version', '1.0.1')),
         array('config.add', array('niechciane_search', 0)),
      );
   }
}
