<?php

/**
*
* moves a post to unwanted posts
*
* @copyright (c) 2019 Z.Lisiecki (zlisiecki)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace evot\move\event;

/**
* @ignore
*/

use phpbb\event\data;
use phpbb\template\template;
use phpbb\user;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var string phpBB root path */
	protected $phpbb_root_path;

	/** @var string phpEx */
	protected $php_ext;

	/** @var string expl1...3 */
	static protected $expl1, $expl2, $expl3;


	public function __construct(
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		$phpbb_root_path,
		$php_ext)
	{
		$this->request			= $request;
		$this->template			= $template;
		$this->user				= $user;
		$this->auth				= $auth;
		$this->phpbb_root_path	= $phpbb_root_path;
		$this->php_ext			= $php_ext;

		//$user->session_begin();
		$auth->acl($user->data);
		$user->setup();
		$user->add_lang_ext('evot/move', 'move');

	}

	/**
	* Assign functions to event listeners
	*/
	static public function getSubscribedEvents()
	{
		// static public is not an object contex for $this
		// $this->user->setup();
		// check for the moderators power
		return array(
			'core.viewtopic_modify_post_row'				=>	'link_a_button',
			'core.viewtopic_assign_template_vars_before'	=>	'link_t_button',
			'core.modify_posting_parameters'				=>	'button_pressed',
			/*
			this was for testing only

					//'core.posting_modify_default_variables'		=>	'button_pressed',
					//'core.mcp_global_f_read_auth_after'			=>	'tools_pressed',
					//'viewtopic_buttons_top_after'					=>	'link_t_button',
					//'core.viewtopic_modify_post_data'				=>	'link_t_button',
					//'core.viewtopic_add_quickmod_option_before'	=>	'link_t_button',
					//'core.viewtopic_modify_post_data'				=>	'tools_pressed',
					//'viewtopic_dropdown_top_custom'				=>	'tools_pressed',
			*/
		);
	}

	/*
	* buttons above each post
	*/
	public function link_a_button ($event)
	{
		global	$user;

		if ($this->auth->acl_getf_global('m_')) {
			$move_allowed = 1;
			$forum_id = $event['row']['forum_id'];
			$post_id = $event['row']['post_id'];

			$phpEx = $this->php_ext;
			$ep = "{$phpbb_root_path}posting.$phpEx";
			$url1 = append_sid($ep, "mode=pmove1&amp;f=$forum_id&amp;p=$post_id");
			$url2 = append_sid($ep, "mode=pmove2&amp;f=$forum_id&amp;p=$post_id");
			$url3 = append_sid($ep, "mode=spam&amp;f=$forum_id&amp;p=$post_id");

			$expl1 = $user->lang['EMOVE_PMOVE1_EXPLAIN'];
			$expl2 = $user->lang['EMOVE_PMOVE2_EXPLAIN'];
			$expl3 = $user->lang['EMOVE_PSPAM_EXPLAIN'];
			if (strnatcasecmp ($topic_title, $user->lang['EMOVE_NIP_TITLE']) == 0 ||
				strnatcasecmp ($topic_title, $user->lang['EMOVE_NAP_TITLE']) == 0 ||
				strnatcasecmp ($topic_title, $user->lang['EMOVE_SPA_TITLE']) == 0) {
				$expl1 = $user->lang['EMOVE_PMOVEB_EXPLAIN'];
				$expl2 = $user->lang['EMOVE_PMOVEB_EXPLAIN'];
				$expl3 = $user->lang['EMOVE_PMOVEB_EXPLAIN'];
			}

			$event['post_row'] = array_merge($event['post_row'], array(
				'PMOVE1_ADDR'		=> $url1,
				'PMOVE1_EXPLAIN'	=> $expl1,
				'PMOVE2_ADDR'		=> $url2,
				'PMOVE2_EXPLAIN'	=> $expl2,
				'PMOVE3_ADDR'		=> $url3,
				'PMOVE3_EXPLAIN'	=> $expl3,
			));
		}
	}

	/*
	* buttons/tools for the whole topic
	*/
	public function link_t_button ($event)
	{
		global $user, $phpbb_root_path, $phpEx, $url1, $url2, $ursl3;

		if ($this->auth->acl_getf_global('m_')) {
			$this->user->setup();
			$this->user->add_lang_ext('evot/move', 'move');
			$forum_id = $event['forum_id'];
			$topic_id = $event['topic_id'];

			include_once($phpbb_root_path . 'ext/evot/move/movelib.' . $phpEx);
			$forum_name = forum_name ($forum_id);

			/* functions for buttons above the whole thread	*/
			$ep = "{$phpbb_root_path}ext/evot/move/move.php";
			$url1 = append_sid($ep, "mode=niechciane&amp;f=$forum_id&amp;t=$topic_id");
			$url2 = append_sid($ep, "mode=nieaktualne&amp;f=$forum_id&amp;t=$topic_id");
			$url3 = append_sid($ep, "mode=spam&amp;f=$forum_id&amp;t=$topic_id");


			/* buttons above each thread	*/
			$this->template->assign_var('L_TMOVE_BUTT', '<a href="'.$url1.'" title="'
				. $user->lang['EMOVE_TMOVE_EXPLAIN'] . '" class="button" >
				<span "padding=24px" >' . $user->lang['EMOVE_NI_TITLE'] . '</span>
			</a>');
			$this->template->assign_var('L_AMOVE_BUTT', '<a href="'.$url2.'" title="'
				. $user->lang['EMOVE_AMOVE_EXPLAIN'] . '" class="button" >
				<span "padding=24px" >' . $user->lang['EMOVE_NA_TITLE'] . '</span>
			</a>');
			$this->template->assign_var('L_SMOVE_BUTT', '<a href="'.$url3.'" title="'
				. $user->lang['EMOVE_TSPAM_EXPLAIN'] . '" class="button" >
				<span "padding=24px" >' . $user->lang['EMOVE_SP_TITLE'] . '</span>
			</a>');

			/* extended tools above each thread	*/
			$this->template->assign_var('L_TMOVE_LIST', '<li class="small-icon ">
				<a href="' . $url1 . '" title="' . $user->lang['EMOVE_TMOVE_EXPLAIN'] . '">' .
				$user->lang['EMOVE_TMOVE_TITLE'] . '</a> </li>');
			$this->template->assign_var('L_AMOVE_LIST', '<li class="small-icon ">
				<a href="' . $url2 . '" title="' . $user->lang['EMOVE_AMOVE_EXPLAIN'] . '">' .
				$user->lang['EMOVE_AMOVE_TITLE'] . '</a> </li>');
			$this->template->assign_var('L_SMOVE_LIST', '<li class="small-icon ">
				<a href="' . $url3 . '" title="' . $user->lang['EMOVE_TSPAM_EXPLAIN'] . '">' .
				$user->lang['EMOVE_SP_TITLE'] . '</a> </li>');
		}
	}

	/*
	* buttons actions
	*/
	public function button_pressed ($event)
	{
		if (!$this->auth->acl_getf_global('m_')) { return (null);	}


		$post_id 	= $event['post_id'];
		$topic_id	= $event['topic_id'];
		$forum_id	= $event['forum_id'];

		// topic_id is 0 here !
		// but we don't need it for post move only for topic move

		if ($event['mode'] == 'pmove1' ||
			$event['mode'] == 'pmove2') {	# move a post
			self::handle_post_move ($event['mode'], $forum_id, $topic_id, $post_id);
		}
		if ($event['mode'] == 'spam') {
			self::handle_spam ($event['mode'], $forum_id, $topic_id, $post_id);
		}
		if ($event['mode'] == 'tmove' ||
			$event['mode'] == 'tspam') {	# move a thread
			//self::handle_topic_move ($forum_id, $topic_id);
			die ('This function is in move.php now <br>');
		}

		// process other button pressed events
		//$event['mode'] == '';
		//$event['cancel'] = yes;	# escape from any further posting
	}

	/*
	* It moves a post to a special topic titeled "niechciane posty".
	* This is not for a general moving a post around.
	*/
	function handle_post_move($mode, $forum_id, $topic_id, $post_id)
	{
		global $user, $db, $auth, $config, $phpbb_root_path, $phpEx;

		if (!$this->auth->acl_getf_global('m_')) {
			trigger_error('NOT_AUTHORISED');
		}
		$sql = 'SELECT topic_id, forum_id, poster_id, post_subject, post_username
			FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
			WHERE p.post_id = ' . $post_id . '
			AND   p.poster_id = u.user_id';
		if (!($result = $db->sql_query($sql))) {
			trigger_error('handle_post_move(): '.$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
		}
		if (!($row = $db->sql_fetchrow($result))) {
			$msg  = 'listener.php -> handle_post_move(): '.$user->lang['EMOVE_CANNOTFETCH'];
			$msg .= '<br>'.$sql.'<br>';
			trigger_error($msg);
		}
		/*
		* this additional check could work only if topic_id != 0
		* unfortunately handle_post_move is called with topic_id 0 now
		if ($topic_id != $row['topic_id']) {
			trigger_error('handle_post_move(): topic_id ' .
				$topic_id . ' != ' . $row['topic_id']);
		}
		*/
		$topic_id = $row['topic_id'];
		if ($topic_id === 0) {
			trigger_error('handle_post_move(): ' .
				$user->lang['EMOVE_TOPIC_ID0'] . $post_id);
		}
		if ($forum_id != $row['forum_id']) {
			trigger_error('handle_post_move(): forum_id ' .
				$forum_id . ' != ' . $row['forum_id']);
		}
		$subject = $row['post_subject'];
		$db->sql_freeresult($result);

		include_once($phpbb_root_path . 'ext/evot/move/movelib.' . $phpEx);
		// this is the person moving this post not the post author
		$who_moves	= $user->data['username'];
		$unwanted_topic_id = find_topic_by_title ($forum_id, $user->lang['EMOVE_NIP_TITLE']);
		if (!$unwanted_topic_id) {
			$message	= $user->lang['EMOVE_NI_TEXT'];
			$title		= $user->lang['EMOVE_NIP_TITLE'];
			$unwanted_topic_id = create_topic ($forum_id, $title, $message);
		}

		if ($topic_id == $unwanted_topic_id) {

			// we are already inside of unwanted topic,
			// move the post back to its' original topic
			self::move_back_post ($forum_id, $topic_id, $post_id);

		} else {

			$url = generate_board_url() . '/' .
				append_sid("viewtopic.php" . "?f=$forum_id&amp;t=$topic_id");

			$msg = '

[color=#FF0000]' .  $user->lang['EMOVE_UWAGA_MODER'] . $who_moves . ':
' . $user->lang['EMOVE_POST_MOVED'] . ' [url]' . $url . '[/url][/color]';

			append_text_to_post ($post_id, $msg);
			move_post_to_another_topic (
				$post_id,
				$topic_id,
				$unwanted_topic_id,
				$forum_id);
		}

		add_log('mod',
			$forum_id,
			$unwanted_topic_id,
			$user->lang['EMOVE_LOG_NIP_MOVED'],
			$subject);


		/*
		* what to do and where to go after this action
		*/
		if ($mode === 'pmove1') {
			$previous_post_id = previous_post ($topic_id, $post_id);
			if ($previous_post_id <= 0) {
				/*
				* No previous post: this is the first one in this topic
				* Ask te user to use another button or to move the whole topic
				*/
				trigger_error($user->lang['EMOVE_NOPREVIOUS']);
			}
			/*
			* do not inform the user, just jump back to this topic
			*/
			$u = "{$phpbb_root_path}viewtopic.$phpEx?f=$forum_id&amp;t=$topic_id";
			$url = generate_board_url() . '/' . append_sid($u, 'p=' .
				$previous_post_id . '#p' . $previous_post_id);
		}
		elseif ($mode === 'pmove2') {
			/*
			* notify the user with PM and jump to the post to possibly edit it
			*/
			$adr = "{$phpbb_root_path}viewtopic.php?f=$forum_id&amp;t=$unwanted_topic_id";
			$adr .= "&amp;t=$topic_id&amp;p=$post_id#p$post_id";
			$url  = '<a href="' . $adr . '">' . $adr . '</a>';
			$msg = sprintf ($user->lang['EMOVE_PM_POST_MOVED'], $url,
				$who_moves, $user->lang['EMOVE_NIP_TITLE']);
			notify_user ($user->data['user_id'], $msg);
			$url = generate_board_url() . '/' . append_sid($adr);
		}
		else {
			trigger_error('handle_post_move(): wrong mode ' . $mode);
		}
		redirect($url);

		//never reached
		$a = "{$phpbb_root_path}viewforum.$phpEx";
		make_jumpbox(append_sid($a,"f=$forum_id&amp;t=$topic_id"));
	}

	/*
	* It moves a post to spam
	*/
	function handle_spam($mode, $forum_id, $topic_id, $post_id)
	{
		global $user, $db, $auth, $config, $phpbb_root_path, $phpEx;

		if (!$this->auth->acl_getf_global('m_')) {
			trigger_error('NOT_AUTHORISED');
		}
		$sql = 'SELECT topic_id, forum_id, poster_id, post_subject, post_username
			FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
			WHERE p.post_id = ' . $post_id . '
			AND   p.poster_id = u.user_id';
		if (!($result = $db->sql_query($sql))) {
			trigger_error('handle_spam(): '.
				$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
		}
		if (!($row = $db->sql_fetchrow($result))) {
			$msg  = 'listener.php -> handle_spam(): '.
				$user->lang['EMOVE_CANNOTFETCH'];
			$msg .= '<br>'.$sql.'<br>';
			trigger_error($msg);
		}
		$topic_id = $row['topic_id'];
		if ($topic_id === 0) {
			trigger_error('handle_spam(): ' .
				$user->lang['EMOVE_TOPIC_ID0'] . $post_id);
		}
		if ($forum_id != $row['forum_id']) {
			trigger_error('handle_spam(): forum_id ' .
				$forum_id . ' != ' . $row['forum_id']);
		}
		$subject = $row['post_subject'];
		$db->sql_freeresult($result);

		include_once($phpbb_root_path . 'ext/evot/move/movelib.' . $phpEx);
		// this is the person moving this post not the post author
		$who_moves	= $user->data['username'];

		if (!($spam_forum_id = find_forum_by_name ($forum_id, 'SPAM'))) {
			$title = $user->lang['EMOVE_SPT_TITLE'];
			$forum_image = 'ext/evot/move/images/spam04.png';
			$forum_desc = $user->lang['EMOVE_SPT_TITLE'];
			$lock_it = true;
			$spam_forum_id = create_forum (
								$forum_id,
								$title,
								$forum_desc,
								$forum_image,
								$lock_it);

			$lock_it = true;
			if (! $spam_forum_id || $spam_forum_id == '') {
				trigger_error ('handle_spam(): Could not create SPAM subforum');
			}
		}

		$spam_topic_id = find_topic_by_title ($spam_forum_id, 'SPAM');
		if (!$spam_topic) {
			$message	= 'individual spam posts are moved to this topic';
			$title		= 'spam topic';
			$spam_topic_id = create_topic ($spam_forum_id, $title, $message);
		}

		if ($topic_id == $spam_topic_id) {
			// we are already in spam topic
			// trigger_error ('This function is not ready yet');

			self::move_back_post ($forum_id, $topic_id, $post_id);

		} else {

			$adr = "{$phpbb_root_path}viewtopic.php" . "?f=$forum_id&amp;t=$topic_id";
			$msg = '

[color=#FF0000]' .  $user->lang['EMOVE_UWAGA_MODER'] . $who_moves . ':
' . $user->lang['EMOVE_POST_MOVED'] . ' [url]http://' . $adr . '[/url][/color]';

			append_text_to_post ($post_id, $msg);
			move_post_to_another_topic ($post_id, $topic_id, $spam_topic_id,
				$spam_forum_id);
		}
		add_log('mod',
			$forum_id,
			$spam_topic_id,
			$user->lang['EMOVE_LOG_SPP_MOVED'],
			$subject);

		$previous_post_id = previous_post ($topic_id, $post_id);
		if ($previous_post_id <= 0) {
			/*
			* No previous post: this is the first one in this topic
			* Ask te user to use another button or to move the whole topic
			*/
			trigger_error($user->lang['EMOVE_NOPREVIOUS']);
		}
		/*
		* do not inform the user, just jump back to this thread
		*/
		$u = "{$phpbb_root_path}viewtopic.$phpEx?f=$forum_id&amp;t=$topic_id";
		$url = append_sid($u, 'p=' . $previous_post_id . '#p' . $previous_post_id);
		redirect($url);

		//never reached
		$a = "{$phpbb_root_path}viewforum.$phpEx";
		make_jumpbox(append_sid($a,"f=$forum_id&amp;t=$topic_id"));
	}


	/**
	* move a post back from niechciane or spam thread
	* to it's initial source thread
	*/
	function move_back_post ($forum_id, $topic_id, $post_id)
	{
		global $config, $db, $user, $phpEx, $auth, $phpbb_root_path, $phpbb_log ;

		$user = $this->user;

		$sql = 'SELECT * FROM ' . POSTS_TABLE . '
				WHERE post_id = ' . $post_id;
        if (!($result = $db->sql_query($sql))) {
            trigger_error('move_back_post(): '.
                $user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
        }
		$row = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);
		$row['bbcode_options'] =
			(($row['enable_bbcode'])    ? OPTION_FLAG_BBCODE :  0) +
			(($row['enable_smilies'])   ? OPTION_FLAG_SMILIES : 0) + 
			(($row['enable_magic_url']) ? OPTION_FLAG_LINKS :   0);
		$message	= generate_text_for_display (
						$row['post_text'],
						$row['bbcode_uid'],
						$row['bbcode_bitfield'],
						$row['bbcode_options']);
		$niechciany_topic_id = $row['topic_id'];
		$post_text = $row['post_text'];
		$poster_id = $row['poster_id'];
		$post_subject = $row['post_subject'];

		$match = array();
		if (preg_match('@.*'.$user->lang['EMOVE_POST_MOVED'].
			'.*viewtopic.*f=(\d*)&.*t=(\d*).*@', $post_text, $match)) {
			// These are original places, where this post was moved from
			$src_forum = $match[1];
			$src_topic = $match[2];
		} else {
			trigger_error('move_back(): ' .
				$user->lang['EMOVE_NO_INFO'].'<br>'.$src_forum.','.$src_topic);
		}
		if ($src_forum === ' ' || $src_forum === 0) {
			trigger_error('move_back(): ' . $user->lang['EMOVE_WRONG_INFO'] .
				' src_forum=' . $src_forum . '<br>');
		}
		if ($src_topic === ' ' || $src_topic === 0) {
			trigger_error('move_back(): ' . $user->lang['EMOVE_WRONG_INFO'] .
				' src_topic=' . $src_topic . '<br>');
		}
		if ($src_topic === $topic_id) {
			trigger_error('move_back(): '.$user->lang['EMOVE_SAME_TOP'].'<br>');
		}
		if ($src_forum != $forum_id) {
			trigger_error('move_back(): '.$user->lang['EMOVE_ANOTHER_FOR'].'<br>');
		}

		// check if an old topic exists in this forum
		$sql = 'SELECT topic_id FROM ' . TOPICS_TABLE . '
				WHERE forum_id = ' . $src_forum . ' AND topic_id = ' . $src_topic;
		if (!($result = $db->sql_query($sql))) {
			trigger_error('move_back(): '.
				$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
		}
		$dst_topic_id = (int) $db->sql_fetchfield('topic_id');

		if ($dst_topic_id == $src_topic) {

			// just move a post
			$db->sql_transaction('begin');
			$sql = 'UPDATE ' . POSTS_TABLE . '
				SET topic_id = ' . $dst_topic_id . '
				WHERE post_id = ' . $post_id;
			if (!($result = $db->sql_query($sql))) {
				trigger_error('move_back(): '.
					$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
			}
			$sql = 'UPDATE ' . ATTACHMENTS_TABLE . '
				SET topic_id = ' . $dst_topic_id . ', in_message = 0
				WHERE post_msg_id = ' . $post_id;
			if (!($result = $db->sql_query($sql))) {
				trigger_error('move_back(): '.
					$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
			}
			$db->sql_transaction('commit');
			delete_trailing_note ($post_id);

		} else {
			/*
			* a topic with such topic_id don't exist any more
			* the former source topic don't exist any more,
			* create it with this post
			*/
			die ("a topic with such topic_id don't exist any more<br>
				d: $dst_topic_id, s: $src_topic <br>");

			$bbcode_uid = $bbcode_bitfield = $flags = '';
			$allow_bbcode = true;
			$allow_urls = true;
			$allow_smilies = true;

			generate_text_for_storage($post_text,
				$bbcode_uid,
				$bbcode_bitfield,
				$flags,
				$allow_bbcode,
				$allow_urls,
				$allow_smilies);

			$data = array( 
				'poster_id'				=> $poster_id,
				'topic_id'				=> 0,
				'forum_id'				=> $forum_id,
				'icon_id'				=> false,
				'enable_bbcode'			=> true,
				'enable_smilies'		=> true,
				'enable_urls'			=> true,
				'enable_sig'			=> true,
				'message'				=> $post_text,
				'message_md5'			=> md5($post_text),
				'bbcode_bitfield'		=> $bbcode_bitfield,
				'bbcode_uid'			=> $bbcode_uid,
				'post_edit_locked'		=> 0,
				'topic_title'			=> $post_subject,
				'post_time'				=> 0,
				'notify_set'			=> false,
				'notify'				=> false,
				'forum_name'			=> '',
				'enable_indexing'		=> true,
				'force_approved_state'	=> true,
				'force_visibility'		=> true,
			);
			$topic_type = 0;
			$poll = 0;
			submit_post ('post', $post_subject,
				$username,  $topic_type,  $poll,  $data);
			$new_post_id = $data['post_id'];
			$topic_id = $data['topic_id'];

			// delete this post in niechciane thread
			$db->sql_transaction('begin');
			$sql = 'DELETE FROM ' . POSTS_TABLE . '
				WHERE post_id = ' . $post_id;
			if (!($result = $db->sql_query($sql))) {
				trigger_error('move_back(): '.
					$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
			}
			$sql = 'UPDATE ' . REPORTS_TABLE . '
				SET post_id = ' . $new_post_id . '
				WHERE post_id = ' . $post_id;
			if (!($result = $db->sql_query($sql))) {
				trigger_error('move_back(): '.
					$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
			}

			// Adjust users post count.        why ?

			$sql = 'UPDATE ' . USERS_TABLE . '
			SET user_posts = user_posts - 1
				WHERE user_id = ' . $poster_id;
			if (!($result = $db->sql_query($sql))) {
				trigger_error('move_back(): '.
					$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
			}
			$db->sql_transaction('commit');

			// Remove the message from the search index
			$search_type = $config['search_type'];
			if (!class_exists($search_type)) {
				trigger_error('NO_SUCH_SEARCH_MODULE');
			}
			$error = false;
			$search = new $search_type(
						$error,
						$phpbb_root_path,
						$phpEx,
						$auth,
						$config,
						$db,
						$user,
						$phpbb_dispatcher);

			if ($error) { trigger_error($error); }
			$post_ids = array ( $post_id,);
			$poster_ids = array ( $poster_id,);
			$forum_ids = array ( $forum_id,);
			$search->index_remove($post_ids, $poster_ids, $forum_ids);

			// end deleting a post
			$post_id = $new_post_id;
		}

		include_once($this->phpbb_root_path .
			'includes/functions_admin.' . $this->php_ext);
		include_once($this->phpbb_root_path .
			'includes/functions_mcp.' . $this->php_ext);

		// Sync topics, forums
		$topic_list = array (
			$old_topic_id,
			$niechciany_topic_id,
		);
		sync('topic', 'topic_id', $topic_list);
		sync('forum', 'forum_id', $forum_id);

		// deprecated
		//add_log('mod',

/*
		$phpbb_log->add('mod',
			$user->data['user_id'],
			$user->data['user_ip'],
			$old_topic_id,
			'EMOVE_LOG_PMOVED_BACK',
			 false,
			 array(
				'forum_id'	=> $forum_id',
				'topic_id'	=> $topic_id',
				'post_id'  	=> $post_id',
				$log_subject,
				(!empty($username)) ? $username : $user->lang['GUEST'],
				$data_ary['post_edit_reason']
			)
		);
*/
		$l1 = $user->lang['EMOVE_RETURN_POST'];
		$l2 = $user->lang['EMOVE_RETURN_NIECH'];
		$l3 = $user->lang['EMOVE_RETURN_FORUM'];

		$vt   = "{$phpbb_root_path}viewtopic.$phpEx";
		$url1 = append_sid ($vt, "f=$forum_id&amp;t=$old_topic_id" .
				'&amp;p=' . $post_id . '#p' . $post_id);
		$url1 = "<a href=\"$url1\"> $l1 </a>";

		$url2 = append_sid ($vt, "f=$forum_id&amp;t=$niechciany_topic_id" .
				'&amp;p=' . $post_id . '#p' . $post_id);
		$url2 = "<a href=\"$url2\"> $l2 </a>";

		$vt   = "{$phpbb_root_path}viewforum.$phpEx";
		$url3 = append_sid ($vt, "f=$forum_id");
		$url3 = "<a href=\"$url3\"> $l3 </a>";

		$msg  = '<br><table cellspacing="12" cellpadding="10">';
		$msg .= '<tr><td colspan="2">' . $user->lang['EMOVE_POST_RETURNED'];
		$msg .= '<tr><td> <td> <br>';
		$msg .= '<tr><td> 1. <td>' . $url1;
		$msg .= '<tr><td> 2. <td>' . $url2;
		$msg .= '<tr><td> 3. <td>' . $url3;
		trigger_error ($msg);
	}
}

?>
