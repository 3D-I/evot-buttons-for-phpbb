<?php

/*
*
* movelib some common functions for move ext
*
* @copyright (c) 2015 Z.Lisiecki (zlisiecki)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* @package evot/move
*
*	$phpbb_root_path must be set
*	$user session, acl and setup started and lang_ext(move added
*/

function notify_user ($who, $msg)
{
	global $user, $db, $auth, $config, $phpbb_root_path, $phpEx;

	include_once($phpbb_root_path . 'includes/functions_privmsgs.' . $phpEx);
	include_once($phpbb_root_path . 'includes/message_parser.' . $phpEx);

	$message_parser = new parse_message();
	$message_parser->message = $msg;
	$message_parser->parse(true, true, true, false, false, true, true);
	$pm_data = array(
		'from_user_id'			=> $user->data['user_id'],
		'from_user_ip'			=> $user->ip,
		'from_username'			=> $user->data['username'],
		'enable_sig'			=> false,
		'enable_bbcode'			=> true,
		'enable_smilies'		=> true,
		'enable_urls'			=> false,
		'icon_id'				=> 0,
		'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
		'bbcode_uid'			=> $message_parser->bbcode_uid,
		'message'				=> $message_parser->message,
		'address_list'			=> array('u' => array($who => 'to')),
	);
	submit_pm(
		'post', 
		$user->lang['EMOVE_POST_TITLE'],
		$pm_data,
		false);
}


/**
* append some trailing text to a post
*/
function append_text_to_post ($post_id, $text)
{
	global $user, $db, $update_message;

	$update_message = true;
	$sql = 'SELECT * FROM ' . POSTS_TABLE . ' WHERE post_id = ' .  $post_id;
	if (!($result = $db->sql_query($sql))) {
		$msg  = 'movelib.php -> append_to_post(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	$row = $db->sql_fetchrow($result);
	if (!$row) {
		$msg  = 'movelib.php -> append_t_post(): ';
		$msg .= $user->lang['EMOVE_CANNOTFETCH'] . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	$db->sql_freeresult($result);

	/*
	* either generate message for display or for editing is used
	*/
	$row['bbcode_options'] =	(($row['enable_bbcode'])    ? OPTION_FLAG_BBCODE :  0) +
   								(($row['enable_smilies'])   ? OPTION_FLAG_SMILIES : 0) + 
   								(($row['enable_magic_url']) ? OPTION_FLAG_LINKS :   0);
	$message	= generate_text_for_display (
					$row['post_text'],
					$row['bbcode_uid'],
					$row['bbcode_bitfield'],
					$row['bbcode_options']);
	/*
	* below is the parsing version for text editing
	decode_message($row['post_text'], $row['bbcode_uid']);
	$message    = $row['post_text'];
	*/

	$message   .= $text;	// concat 
	$forum_id	= $row['forum_id'];
	$edit_count	= $row['post_edit_count'];
	$allow_smilies	= $row['allow_smilies'];
	// this is the person appending to this post not the originale post author
	$who_appends	= $user->data['username'];

	// disregard locked topics
	// disregard Lock/Unlock Post Edit now

	$message = utf8_normalize_nfc($message);
	// this will be modified by generate_text_for_storage
	$bbcode_uid = $bbcode_bitfield = $flags = '';
	$allow_bbcode = true;
	$allow_urls = true;
	generate_text_for_storage($message,
		$bbcode_uid,
		$bbcode_bitfield,
		$flags,
		$allow_bbcode,
		$allow_urls,
		$allow_smilies);
	$sql_ary = array(
		'enable_bbcode'		=> true,
		'enable_magic_url'	=> true,
		'post_text'			=> $message,
		'post_checksum'		=> md5($message),
		'bbcode_bitfield'	=> $bbcode_bitfield,
		'bbcode_uid'		=> $bbcode_uid,
		'post_edit_time'	=> time(),
		'post_edit_reason'	=> $user->lang['EMOVE_MODER_NOTE'],
		'post_edit_user'	=> $user->data['user_id'],
		'post_edit_count'	=> $edit_count + 1,
	);
	$sql = 'UPDATE ' . POSTS_TABLE . '
			SET ' . $db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE post_id = ' . $post_id;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('append_to_post(): ' . $user->lang['EMOVE_CANNOTQUERY'] .
			'<br>' . $sql . '<br>');
	}
}

/**
* delete a trailing moderators note from a post
*/
function delete_trailing_note ($post_id)
{
	global $user, $db, $update_message;

	$update_message = true;
	$sql = 'SELECT * FROM ' . POSTS_TABLE . ' WHERE post_id = ' .  $post_id;
	if (!($result = $db->sql_query($sql))) {
		$msg  = 'movelib.php -> append_to_post(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	$row = $db->sql_fetchrow($result);
	if (!$row) {
		$msg  = 'movelib.php -> append_t_post(): ';
		$msg .= $user->lang['EMOVE_CANNOTFETCH'] . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	$db->sql_freeresult($result);

	/*
	* either generate message for display or for editing is used
	*/
	$row['bbcode_options'] =	(($row['enable_bbcode'])    ? OPTION_FLAG_BBCODE :  0) +
   								(($row['enable_smilies'])   ? OPTION_FLAG_SMILIES : 0) + 
   								(($row['enable_magic_url']) ? OPTION_FLAG_LINKS :   0);

	$haystack = $row['post_text'];
	$needle   = '<COLOR color="#FF0000"><s>[color=#FF0000]</s>';
	$needle  .= $user->lang['EMOVE_UWAGA_MODER'];
	$len = strlen ($haystack);
	$n   = strripos ($haystack, $needle);
	$msg = substr ($haystack, 0, $len - $n);

	$message	= generate_text_for_display (
					$msg,
					$row['bbcode_uid'],
					$row['bbcode_bitfield'],
					$row['bbcode_options']);
	/*
	* below is the parsing version for text editing
	decode_message($row['post_text'], $row['bbcode_uid']);
	$message    = $row['post_text'];
	*/

	$forum_id		= $row['forum_id'];
	$edit_count		= $row['post_edit_count'];
	$allow_smilies	= $row['allow_smilies'];
	$who_appends	= $user->data['username'];

	// disregard locked topics
	// disregard Lock/Unlock Post Edit now

	//$message = utf8_normalize_nfc($message);
	// this will be modified by generate_text_for_storage
	$bbcode_uid = $bbcode_bitfield = $flags = '';
	$allow_bbcode = true;
	$allow_urls = true;
	generate_text_for_storage($message,
		$bbcode_uid,
		$bbcode_bitfield,
		$flags,
		$allow_bbcode,
		$allow_urls,
		$allow_smilies);
	$sql_ary = array(
		'enable_bbcode'		=> true,
		'enable_magic_url'	=> true,
		'post_text'			=> $message,
		'post_checksum'		=> md5($message),
		'bbcode_bitfield'	=> $bbcode_bitfield,
		'bbcode_uid'		=> $bbcode_uid,
		'post_edit_time'	=> time(),
		'post_edit_reason'	=> $user->lang['EMOVE_MODER_NOTE'],
		'post_edit_user'	=> $user->data['user_id'],
		'post_edit_count'	=> $edit_count + 1,
	);
	$sql = 'UPDATE ' . POSTS_TABLE . '
			SET ' . $db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE post_id = ' . $post_id;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('append_to_post(): ' . $user->lang['EMOVE_CANNOTQUERY'] .
			'<br>' . $sql . '<br>');
	}
}


/*
* move a post to another topic
*/
function move_post_to_another_topic ($post_id, $old_topic_id, $new_topic_id, $forum_id)
{
	global $user, $db, $phpbb_root_path, $phpEx;

	$sql = 'SELECT forum_id FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . $post_id;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('move_post_to_another_topic(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$pforum_id = (int) $db->sql_fetchfield('forum_id');

	$db->sql_transaction('begin');
	$sql = 'UPDATE ' . POSTS_TABLE . '
		SET topic_id = ' . $new_topic_id . ', 
			forum_id = ' . $forum_id . '
		WHERE post_id = ' . $post_id;
	if (!$db->sql_query($sql)) {
		trigger_error('move_post_to_another_topic(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$sql = 'UPDATE ' . ATTACHMENTS_TABLE . '
		SET topic_id = ' . $new_topic_id . ', in_message = 0
		WHERE post_msg_id = ' . $post_id;
	if (!$db->sql_query($sql)) {
		trigger_error('move_post_to_another_topic(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$db->sql_transaction('commit');

	// Sync topics
	$topic_ids = array (
		$old_topic_id,
		$new_topic_id,
	);
	$forum_ids = array (
		$forum_id,
		$pforum_id,
	);

	include_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
	sync('topic_reported', 'topic_id', $topic_ids);
	sync('topic_attachment', 'topic_id', $topic_ids);
	sync('topic', 'topic_id', $topic_ids, true);
	sync('forum', 'forum_id', $forum_ids, true, true);
	update_posted_info($topic_ids);
}


/**
* create a topic with a given title and first post
*/
function create_topic ($forum_id, $title, $post)
{
	global $user, $db, $auth, $config, $phpbb_root_path, $phpEx;

	$uid = '';
	$bitfield = '';
	$flags = 0;

	$bbcode_uid = $bbcode_bitfield = $flags = '';
	// bbcode_uid will be modified by generate_text_for_storage
	$allow_bbcode = true;
	$allow_urls = true;
	$allow_smilies = true;

	generate_text_for_storage($post,
	$bbcode_uid,
	$bbcode_bitfield,
	$flags,
	$allow_bbcode,
	$allow_urls,
	$allow_smilies);

	$data = array( 
		'forum_id'				=> $forum_id,
		'topic_id'				=> 0,
		'icon_id'				=> false,
		'enable_bbcode'			=> true,
		'enable_smilies'		=> true,
		'enable_urls'			=> true,
		'enable_sig'			=> false,
		'message'				=> $post,
		'message_md5'			=> md5($post),
		'bbcode_bitfield'		=> $bbcode_bitfield,
		'bbcode_uid'			=> $bbcode_uid,
		'post_edit_locked'		=> 0,
		'topic_title'			=> $title,
		'notify_set'			=> false,
		'notify'				=> false,
		'post_time'				=> 0,
		'forum_name'			=> '',
		'enable_indexing'		=> false,
		'force_approved_state'	=> true,
		'force_visibility'		=> true,
	);

	$sql = 'SELECT username FROM ' . USERS_TABLE . ' WHERE user_type = 3';
	if (!($result = $db->sql_query($sql))) {
		trigger_error('create_topic(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	if (!($row = $db->sql_fetchrow($result))) {
		trigger_error('create_topic(): '.
			$user->lang['EMOVE_CANNOTFETCH'].'<br>'.$sql.'<br>');
	}
	$db->sql_freeresult($result);
	$username = $row['username'];

	$topic_type = 1;
	$poll = 0;
	submit_post ('post', $title,  $username,  $topic_type,  $poll,  $data);
	$topic_id = $data['topic_id'];
	$post_id  = $data['post_id'];
	set_to_start_date ($post_id);

	set_config_count('num_topics', 1, true);
	set_config_count('num_posts', 1, true);

	add_log('mod',
		$forum_id,
		$topic_id,
		$user->lang['EMOVE_LOG_TOPIC_ADD'],
		$title);

	return ($topic_id);
}


/**
* set the time of this post to forum start date
*/
function set_to_start_date ($post_id)
{
	global $db;

	$sql = 'SELECT min(post_id) as m FROM ' . POSTS_TABLE;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('set_to_start_date(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$minpost_id = (int) $db->sql_fetchfield('m');
	if (!$minpost_id || $minpost_id <= 0) {
		trigger_error('set_to_start_date(): minimal post_id = ' . 
			$minpost_id.'<br>');
	}
	$sql = 'SELECT post_time FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . $minpost_id;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('set_to_start_date(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$mintime = (int) $db->sql_fetchfield('post_time');
	//$mintime -= 60;
	if ($mintime <= 0) {
		trigger_error('set_to_start_date(): minimal time = ' . $mintime);
	}
	$sql = 'UPDATE ' . POSTS_TABLE . '
			SET post_time = ' . $mintime . '
			WHERE post_id = ' . $post_id;
	if (!($result = $db->sql_query($sql))) {
		trigger_error('set_to_start_date(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$db->sql_freeresult($result);
	return (0);
}


/**
* find a first post in a topic
*/
function first_post_in_topic ($topic_id)
{
	global $db;

	$sql = 'SELECT post_id FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . $topic_id . ' 
			ORDER BY post_id ASC';
	if (!($result = $db->sql_query($sql))) {
		trigger_error('find_first_post(): '.
			$user->lang['EMOVE_CANNOTQUERY'].'<br>'.$sql.'<br>');
	}
	$row = $db->sql_fetchrow($result);
	if (!$row) {
		$msg  = 'movelib.php -> first_post_in_topic(): ';
		$msg .= $user->lang['EMOVE_CANNOTFETCH'] . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	$db->sql_freeresult($result);
	return ((int) $row['post_id']);
}


/**
* find a previous post in this topic
*/
function previous_post ($topic_id, $post_id)
{
	global $user, $db;

	$sql = 'SELECT post_id FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . $topic_id . ' 
			AND post_id < ' . $post_id . '
			ORDER BY post_id DESC';
	$result = $db->sql_query($sql);
	if (!$result) {
		return (-1);
	}
	if (!($row = $db->sql_fetchrow($result))) {
		// no previous post in this thread, i.e. this post was the thread begin.
		// consider moving the whole thread to niechciane.
		$msg .= $user->lang['EMOVE_CANNOTMOVEFIRST'] . '<br>';
		trigger_error($msg);
	}
	$db->sql_freeresult($result);
	$previous_post_id = $row['post_id'];
	return ($previous_post_id);
}


function forum_name ($forum_id)
{
	global $user, $db;

	$sql = 'SELECT forum_name FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . $forum_id . ' ;';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'movelib.php -> forum_name(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	return ($db->sql_fetchfield('forum_name'));
}


function parent_forum ($forum_id)
{
	global $user, $db;

	$sql = 'SELECT parent_id FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . $forum_id . ' ;';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'movelib.php -> parent_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	return ((int) $db->sql_fetchfield('parent_id'));
}


/**
* find a topic by it's title
*/
function find_topic_by_title ($forum_id, $title)
{
	global $user, $db;

	$sql = 'SELECT topic_id FROM ' . TOPICS_TABLE . '
			WHERE forum_id = ' . $forum_id . ' 
			AND topic_title LIKE \'' . $title . '\'';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'movelib.php -> find_topic_by_title(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	if (!($topic_id = (int) $db->sql_fetchfield('topic_id'))) {
		/* such topic don't exist	*/
		return (0);
	}
	return ($topic_id);
}


/**
* find a subforum by it's name
*/
function find_forum_by_name ($parent_id, $forum_name)
{
	global $user, $db;

	$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE . '
			WHERE parent_id = ' . $parent_id . ' 
			AND forum_name LIKE \'' . $forum_name . '\'';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'movelib.php -> find_forum_by_name(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	if (!($forum_id = (int) $db->sql_fetchfield('forum_id')) || $forum_id === 0) {
		/* such forum don't exist	*/
		return (0);
	}
	return ($forum_id);
}


/*
* find the topic title
*/
function topic_title ($topic_id)
{
	global $user, $db;
	$sql = 'SELECT topic_title FROM ' . TOPICS_TABLE . '
			WHERE topic_id = \'' . $topic_id . '\'';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'move.php -> topic_title(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	$topic_title = (int) $db->sql_fetchfield('topic_title');
	if (!$topic_title || $topic_title === NULL) {
		$msg  = 'move.php -> topic_title(): ';
		$msg .= $user->lang['EMOVE_T_NO_TITLE'] . $topic_id . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	return ($topic_title);
}


/*
* find the author of a topic
*/
function topic_author ($topic_id, $first_post_id = NULL)
{
	global $user, $db;
	$sql = 'SELECT topic_poster FROM ' . TOPICS_TABLE . '
			WHERE topic_id = \'' . $topic_id . '\'';
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'move.php -> topic_author(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}
	$user_id = (int) $db->sql_fetchfield('topic_poster');
	if (!$user_id || $user_id === 0) {
		$msg  = 'move.php -> topic_author(): ';
		$msg .= $user->lang['EMOVE_T_NO_AUTHOR'] . $topic_id . '<br>' . $sql . '<br>';
		trigger_error ($msg);
	}

	/*
	* if the first post in this topic is provided
	* check if this has also the same author
	*/
	if ($first_post_id) {
		$sql = 'SELECT poster_id FROM ' . POSTS_TABLE . '
				WHERE post_id = \'' . $first_post_id . '\'';
		$result = $db->sql_query($sql);
		if (!$result) {
			$msg  = 'move.php -> author(): ';
			$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>' . $sql . '<br>';
			trigger_error ($msg);
		}
		$post_user_id = (int) $db->sql_fetchfield('poster_id');
		if (!$post_user_id || $post_user_id === 0) {
			$msg  = 'move.php -> author(): ';
			$msg .= $user->lang['EMOVE_P_NO_AUTHOR'] . $first_post_id;
			trigger_error ($msg);
		}

		if ($post_user_id != $user_id) {
			$msg  = 'move.php -> author(): ';
			$msg .= $user->lang['EMOVE_NO_AUTHOR'] . '<br>';
			$msg .= 'topic_id = ' . $topic_id . ' topic_poster = ' . $user_id;
			$msg .= 'user_id of the first post = ' . $post_user_id . ', ';
			$msg .= 'first post_id: ' . $first_post_id;
			trigger_error ($msg);
		}
	}
	return ($user_id);
}


/**
* create a forum with a given name
* call it with forum_image 'images/forumicons/trashcan.png'
*/
function create_forum ($parent_id, $forum_name, $forum_desc, $forum_image, $lock_it)
{
	global $user, $db, $auth, $cache, $phpbb_root_path, $phpEx;

	/*
	* check permissions if this is a generaly used routine
	* otherwise do not check and the caller must know

	if (!$auth->acl_get('a_forumadd')) {
		trigger_error($user->lang['NO_PERMISSION_FORUM_ADD'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
	}
	*/

	$sql = 'SELECT left_id, right_id, forum_type
			FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . $parent_id;
	$result = $db->sql_query($sql);
	if (!$result) {
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	if (!($row = $db->sql_fetchrow($result))) {
		/*
		* improper call, no parent forum exists !
		*
		trigger_error($user->lang['PARENT_NOT_EXIST'] .
			adm_back_link($this->u_action .
			'&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
		*
		* needs u_action to call the above
		*/
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['PARENT_NOT_EXIST'] . ' ' . $parent_id . '<br>';
		trigger_error($msg, E_USER_WARNING);
	}
	$db->sql_freeresult($result);
	if ($row['forum_type'] == FORUM_LINK) {
		return $errors;
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['PARENT_IS_LINK_FORUM'] . ' ' . $parent_id . '<br>';
		trigger_error($msg, E_USER_WARNING);
	}

	include_once($phpbb_root_path . 'includes/constants.' . $phpEx);
	if ($lock_it)	{
		$forum_status = ITEM_LOCKED;
		$forum_flags = 0;
	} else 			{
		$forum_status = ITEM_UNLOCKED;
		$forum_flags = FORUM_FLAG_POST_REVIEW;
	}

	$forum_data_sql = array (
		'parent_id'					=> $parent_id,
		'left_id'					=> $row['right_id'],
		'right_id'					=> $row['right_id'] + 1,
		'forum_parents'				=> '',
		/*
		* use generate_text_for_storage() for a general use
		*/
		'forum_name'				=> utf8_normalize_nfc($forum_name),
		'forum_desc'				=> utf8_normalize_nfc($forum_desc),
		'forum_desc_bitfield'		=> '',
		'forum_desc_options'		=> 7,
		'forum_desc_uid'			=> '',
		'forum_link'				=> '',
		'forum_password'			=> '',
		'forum_style'				=> 0,
		'forum_image'				=> $forum_image,
		'enable_shadow_prune'		=> false,
		'prune_shadow_days'			=> 7,
		'prune_shadow_freq'			=> 1,
		'prune_shadow_next'			=> 0,
		'forum_rules'				=> '',
		'forum_rules_link'			=> '',
		'forum_rules_bitfield'		=> '',
		'forum_rules_options'		=> 7,
		'forum_rules_uid'			=> '',
		'forum_topics_per_page'		=> 0,
		'forum_type'				=> FORUM_POST,
		'forum_status'				=> $forum_status,
		'forum_last_post_id'		=> 0,
		'forum_last_poster_id'		=> 0,
		'forum_last_post_subject'	=> '',
		'forum_last_post_time'		=> 0,
		'forum_last_poster_name'	=> '',
		'forum_last_poster_colour'	=> '',
		'forum_flags'				=> $forum_flags,
		'display_subforum_list'		=> true,
		'display_on_index'			=> true,
		/*
		* set indexing by a call parameter for a general use of this function
		* here do not index	now !
		*/
		'enable_indexing'			=> false,
		'enable_icons'				=> true,
		'enable_prune'				=> false,
		'prune_next'				=> 0,
		'prune_days'				=> 7,
		'prune_viewed'				=> 7,
		'prune_freq'				=> 1,
		'forum_options'				=> 0,
		'forum_posts_approved'		=> 0,
		'forum_posts_unapproved'	=> 0,
		'forum_posts_softdeleted'	=> 0,
		'forum_topics_approved'		=> 0,
		'forum_topics_unapproved'	=> 0,
		'forum_topics_softdeleted'	=> 0,
		'enable_shadow_prune'		=> false,
		'prune_shadow_days'			=> 7,
		'prune_shadow_freq'			=> 1,
		'prune_shadow_next'			=> 0,
	);

	/*
	* begin db update here
	*/
	$db->sql_transaction('begin');
	$sql = 'UPDATE ' . FORUMS_TABLE . '
			SET left_id = left_id + 2, right_id = right_id + 2
			WHERE left_id > ' . $row['right_id'];
	if (!($result = $db->sql_query($sql))) {
		$db->sql_transaction('rollback');
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	$sql = 'UPDATE ' . FORUMS_TABLE . '
			SET right_id = right_id + 2
			WHERE ' . $row['left_id'] . ' BETWEEN left_id AND right_id';
	if (!($result = $db->sql_query($sql))) {
		$db->sql_transaction('rollback');
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}

	$sql = 'INSERT INTO ' . FORUMS_TABLE . ' ' .
		 $db->sql_build_array('INSERT', $forum_data_sql);
	if (!($result = $db->sql_query($sql))) {
		$db->sql_transaction('rollback');
		$msg  = 'movelib.php -> create_forum(): ';
		$msg .= $user->lang['EMOVE_CANNOTQUERY'] . '<br>'.$sql.'<br>';
		trigger_error($msg);
	}
	$forum_id = $db->sql_nextid();
	$db->sql_transaction('commit');

	include_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
	$log_it = false;
	if (!copy_forum_permissions ($parent_id, $forum_id, $log_it)) {
		$msg  = 'move.php:  copy_permissions: ';
		$msg .= $user->lang['EMOVE_CFP_FAILED'];
		trigger_error ($msg);
	}
	/* this must be called whenever permissions are changed	*/
	phpbb_cache_moderators($db, $cache, $auth);

	include_once($phpbb_root_path . 'includes/acp/acp_forums.' . $phpEx);
	$auth->acl_clear_prefetch();
	$cache->destroy('sql', FORUMS_TABLE);

	$forum_ids = array (
		$forum_id,
		$parent_id,
	);
	sync('forum', 'forum_id', $forum_ids, true, true);

	add_log('mod',
		$forum_id,
		$topic_id,
		$user->lang['EMOVE_LOG_FORUM_ADD'],
		$forum_new,
		$forum_name);

	return ($forum_id);
}

?>
